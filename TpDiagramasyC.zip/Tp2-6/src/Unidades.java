public class Unidades {
    private int idInterno;
    private int cantidadPasajero;

    public Unidades(int idInterno, int cantidadPasajero) {
        this.idInterno = idInterno;
        this.cantidadPasajero = cantidadPasajero;
    }

    public int getIdInterno() {
        return idInterno;
    }

    public void setIdInterno(int idInterno) {
        this.idInterno = idInterno;
    }

    public int getCantidadPasajero() {
        return cantidadPasajero;
    }

    public void setCantidadPasajero(int cantidadPasajero) {
        this.cantidadPasajero = cantidadPasajero;
    }
}
